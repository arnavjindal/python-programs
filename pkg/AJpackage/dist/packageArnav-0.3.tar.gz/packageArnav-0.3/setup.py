
from setuptools import setup
setup(name="packageArnav",
version="0.3",
description="This is code with arnav package",
long_description = "This is a very very long description",
author="AJ",
packages=['packageArnav'],
install_requires=[])
