class waw():
    def __init__(self,Name):
        print("Constructor ban gaya")
        print(f"{self.Name} welcome to this world")

    def achhafunc(self, number):
        print("This is a function")
        return number

        